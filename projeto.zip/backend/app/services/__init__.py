"""
Arquivo: __init__.py
Descrição: Este arquivo faz parte do projeto e foi comentado para explicar a função de cada bloco de código.
"""

from .pgc_service import coleta_pgc, processar_dados_brutos_pgc
