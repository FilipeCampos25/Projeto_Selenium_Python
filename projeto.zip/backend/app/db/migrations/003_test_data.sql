-- 003_test_data.sql (MOVED)
-- Este arquivo foi movido para `migrations_archived/003_test_data.sql` para evitar aplicação automática.
-- Não executar: conteúdo de testes e dados de exemplo arquivado.

